export const addPost = (req,res)=>{
    res.json("from controller")
}