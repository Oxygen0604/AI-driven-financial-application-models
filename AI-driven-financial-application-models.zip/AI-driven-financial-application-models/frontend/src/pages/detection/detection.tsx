import React from'react';
import "./detection.scss"

const Detection = () => {
  return (
    <div className="detection"></div>
    )
}

export default Detection;