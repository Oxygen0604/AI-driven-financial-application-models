import React from'react';
import "./user.scss";

const User = () => {
  return (
    <div className="user"></div>
    );
}

export default User;