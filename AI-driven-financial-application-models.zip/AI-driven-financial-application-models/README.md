# AI-driven-financial-application-models

如何？启动<BR>
首先修改server文件夹里config/dbConfig.json文件<BR>
然后确保当前文件夹为AI-driven-financial-application-models-main<BR>




忽略以下内容  目前需要单独开启前后端<BR>
使用命令<BR>
`npm i`<BR>
`npm start`<BR>
一键打开前后端
